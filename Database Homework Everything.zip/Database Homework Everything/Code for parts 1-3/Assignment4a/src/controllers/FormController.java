package controllers;

import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Produces;

import beans.Order;
import beans.User;
import business.AnotherOrdersBusinessService;
import business.MyTimerService;
import business.OrdersBusinessService;
import model.MyOrder;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;
import javax.ejb.LocalBean;


@ManagedBean 

public class FormController {
	
	@Inject 
	OrdersBusinessService obs;
	
	@PersistenceContext(unitName="assignment4a")
	private EntityManager em;
	 
	public String onSubmit() {
		
		//Get the user value from the input form;
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		
		//System.out.println("You clicked the submit button: " + user.getFirstName() +" " + user.getLastName());
		//List orders = em.createNamedQuery("MyOrder.findAll", MyOrder.class ).getResultList();
		List orders = findAll();
		System.out.println("===> Number of ordered returned is " + orders.size());
		//obs.test();
		
		// start a timer when the login is clicked
		
		// Send the information to the POST request
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		
		//To open  new page after the button is hit, return the file name of the desired page
		return "Response.xhtml";
	}
	
	
	public List<Order> findAll() {
    	Connection conn = null;
    	List<Order> orders  = new ArrayList<>();
		String url = "jdbc:postgresql://localhost:5432/testapp";
		String username = "postgres";
		String password = "googoo11";
		String sql = "SELECT * FROM testapp.testapp.Orders";
		try {
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery(sql);
			while(res.next()) {
				orders.add(new Order(res.getString("ORDER_NO"), res.getString("PRODUCT_NAME"), res.getFloat("PRICE"), res.getInt("QUANTITY")));
			}
			res.close();
		}
		catch(SQLException e){
			e.printStackTrace();
			//System.out.println("Failure!");
		}
		finally {
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return orders;
    }
	
	public OrdersBusinessService getService() {
				obs.getOrder();
				return obs;
	}
	
	
	public String onFlash() {
		System.out.println("Flash!");
		FacesContext context = FacesContext.getCurrentInstance();
		User user = context.getApplication().evaluateExpressionGet(context, "#{user}", User.class);
		 FacesContext.getCurrentInstance().getExternalContext().getFlash().put("#{username}", "Hello World!");
		    return "TestResponse.xhtml?faces-redirect=true";
	}

}
