package beans;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;

import business.OrdersBusinessInterface;
import model.MyOrder;

@ManagedBean
@ViewScoped 
public class Orders {
	
	public static List<MyOrder> orders = new ArrayList<MyOrder>();
	
	@Inject
	OrdersBusinessInterface service;
	
	public Orders() {
	}

	

	
	
	public List<MyOrder> getOrder() {
		return service.getOrder();
	}

	
}
