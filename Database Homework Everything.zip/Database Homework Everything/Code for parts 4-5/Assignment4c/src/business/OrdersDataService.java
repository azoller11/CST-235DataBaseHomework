package business;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import data.DataAccessInterface;
import model.MyOrder;
@Stateless
@LocalBean
@Alternative
public class OrdersDataService implements DataAccessInterface {

	@PersistenceContext(unitName="assignment4c")
	private EntityManager em;

	
	String url = "jdbc:postgresql://localhost:5432/testapp";
	String username = "postgres";
	String password = "googoo11";
	String sql = "SELECT * FROM testapp.testapp.Orders";
	String insertSQL = "INSERT INTO testapp.testapp.Orders(ORDER_NO, PRODUCT_NAME, PRICE, QUANTITY) VALUES('001122334455', 'This was inserted new', 25.0 , 4)";
	
	
	@Override
	public List<MyOrder> findAll() {
		Connection conn = null;
    	List<MyOrder> orders  = new ArrayList<>();
		try {
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery(sql);
			while(res.next()) {
				MyOrder mo = new MyOrder();
				mo.setOrderNo(res.getString("ORDER_NO"));
				mo.setProductName(res.getString("PRODUCT_NAME"));
				mo.setPrice(res.getFloat("PRICE"));
				mo.setQuantity(res.getInt("QUANTITY"));
				orders.add(mo);
			}
			res.close();
		}
		catch(SQLException e){
			e.printStackTrace();
			//System.out.println("Failure!");
		}
		finally {
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return orders;
	}


	@Override
	public MyOrder findById(int id) {
		MyOrder found = null;
		for (MyOrder e : findAll()) {
			if (e.getId() == id) {
				found = e;
			}
		}
		return found;
	}


	@Override
	public void create(MyOrder order) {
		Connection conn = null;
		try {
			conn = DriverManager.getConnection(url, username, password);
			Statement stmt = conn.createStatement();
			ResultSet res = stmt.executeQuery(insertSQL);
			res.insertRow();
			
			res.close();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		
	}


	@Override
	public void update(MyOrder order) {
		// TODO Auto-generated method stub
		
	}


	@Override
	public void delete(MyOrder order) {
		// TODO Auto-generated method stub
		
	}
	
	

}
