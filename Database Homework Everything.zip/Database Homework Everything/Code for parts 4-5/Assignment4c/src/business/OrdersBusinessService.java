package business;

import java.util.List;

import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;

import model.MyOrder;

/**
 * Session Bean implementation class OrderBusinessService
 */
@Stateless
@LocalBean
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {
	public OrdersBusinessService() {
		//orders.add(new Order("100" , "This is product: 1", (float) (Math.random() * 100.0),1));
	}

	@EJB
	OrdersDataService service;
	
	@Override
	public List<MyOrder> getOrder() {
		return service.findAll();
	}

	@Override
	public List<MyOrder> findAll() {
		return service.findAll();
	}

	@Override
	public MyOrder findById(int id) {
		// TODO Auto-generated method stub
		return service.findById(id);
	}

	@Override
	public void create(MyOrder order) {
		service.create(order);
		
	}

	@Override
	public void update(MyOrder order) {
		service.create(order);
		
	}

	@Override
	public void delete(MyOrder order) {
		service.delete(order);
		
	}


}
