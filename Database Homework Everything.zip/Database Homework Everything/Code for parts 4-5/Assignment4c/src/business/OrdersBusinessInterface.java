package business;

import java.util.List;

import javax.ejb.Local;

import model.MyOrder;


@Local
public interface OrdersBusinessInterface  {
	
	public List<MyOrder> getOrder();
	
	public List<MyOrder> findAll();
	public MyOrder findById(int id);
	public void create(MyOrder order);
	public void update(MyOrder order);
	public void delete(MyOrder order);

	
	

}
